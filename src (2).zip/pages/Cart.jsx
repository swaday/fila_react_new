import React from 'react';

function Cart({ items, onDelete, onToggleCheck }) {
    const totalPrice = items
        .filter(item => item.checked)
        .reduce((sum, item) => sum + (item.price * item.quantity), 0);

    return (
        <div style={{ padding: '50px 40px', display: 'flex', gap: '40px', maxWidth: '1200px', margin: '0 auto' }}>
            <div style={{ flex: 2 }}>
                <h2 style={{ fontSize: '22px', fontWeight: 'bold', marginBottom: '20px' }}>장바구니 목록 ({items.length})</h2>
                <div style={{ borderTop: '2px solid #111' }}>
                    {items.length === 0 ? (
                        <p style={{ padding: '70px 0', color: '#999', textAlign: 'center', fontSize: '15px' }}>장바구니 내역이 존재하지 않습니다.</p>
                    ) : (
                        items.map(item => (
                            <div key={item.id} style={{ display: 'flex', alignItems: 'center', gap: '20px', padding: '20px 0', borderBottom: '1px solid #eee', position: 'relative' }}>
                                <input
                                    type="checkbox"
                                    checked={item.checked}
                                    onChange={() => onToggleCheck(item.id)}
                                    style={{ width: '20px', height: '20px', cursor: 'pointer', accentColor: '#002f6c' }}
                                />
                                <img src={item.image} alt={item.name} style={{ width: '85px', height: 'auto', borderRadius: '4px', border: '1px solid #eee' }} />
                                <div style={{ display: 'flex', flexDirection: 'column', gap: '3px' }}>
                                    <h4 style={{ color: '#aaa', fontSize: '12px', margin: 0 }}>{item.brand}</h4>
                                    <p style={{ fontSize: '15px', color: '#111', margin: 0, fontWeight: '500' }}>{item.name}</p>
                                    <p style={{ color: '#777', fontSize: '13px', margin: 0 }}>{item.option}</p>
                                    <p style={{ fontWeight: 'bold', fontSize: '15px', margin: '3px 0 0 0' }}>{item.price.toLocaleString()}원</p>
                                </div>
                                <button
                                    onClick={() => onDelete(item.id)}
                                    style={{ position: 'absolute', right: '10px', top: '20px', background: 'none', border: 'none', fontSize: '18px', cursor: 'pointer', color: '#ccc' }}
                                >✕</button>
                            </div>
                        ))
                    )}
                </div>
            </div>
            <div style={{ flex: 1, border: '1px solid #e2e2e2', padding: '25px', height: 'fit-content', background: '#fcfcfc', borderRadius: '6px' }}>
                <h3 style={{ fontSize: '17px', fontWeight: 'bold', marginBottom: '20px' }}>결제정보</h3>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '15px', color: '#555', fontSize: '14px' }}>
                    <span>상품 합계금액</span>
                    <span>{totalPrice.toLocaleString()}원</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '20px', color: '#555', fontSize: '14px' }}>
                    <span>배송비</span>
                    <span style={{ color: '#002f6c' }}>무료</span>
                </div>
                <div style={{ borderTop: '1px solid #eee', paddingTop: '15px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontWeight: 'bold' }}>
                    <span style={{ fontSize: '15px' }}>최종 주문금액</span>
                    <span style={{ color: '#ff4d4f', fontSize: '22px' }}>{totalPrice.toLocaleString()}원</span>
                </div>
                <button style={{ width: '100%', padding: '16px', background: '#002f6c', color: '#fff', border: 'none', fontWeight: 'bold', cursor: 'pointer', fontSize: '15px', borderRadius: '4px', marginTop: '25px' }}>
                    주문서 작성하기
                </button>
            </div>
        </div>
    );
}

export default Cart;
